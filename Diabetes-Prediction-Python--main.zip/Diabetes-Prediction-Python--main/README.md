# Diabetes-Prediction-Python-

Download the word doc which contains python code in it
Download the dataset
